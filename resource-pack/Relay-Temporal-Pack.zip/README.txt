Relay Temporal overlay for Minecraft Java 1.21.11. Place ABOVE the existing Bliss resource pack. The supplied archive was an overlay without pack.mcmeta; this release includes metadata. Existing glyphs, finale shaders/overlays, textures and sounds are preserved. Adds blissgems:temporal_clock and temporal_hand item models. Set mythics.relay.temporal.dilate.display-models=false and temporal.hud.use-glyphs=false for a pack-free fallback.

Antique palette revision: Time Dilate uses #5A3A1C main markings, #92613B secondary rings, #C99855 restrained accents. The two existing model IDs, geometry, UVs, interpolation and rotation remain unchanged. Existing full-bright displays keep the gold accents readable at night; this does not add shader bloom or world lighting. Replace/reload the client overlay for the model recolor, no new server JAR is needed for that. The optional updated JAR also recolors the pack-free particle fallback.

Texture path fix: the three temporal_*.png material textures now live in assets/blissgems/textures/item/ (was textures/effect/, a folder Minecraft does not load for models). Colours, geometry and model IDs are unchanged.

Rift + Time Dilate restyle: adds blissgems:rift_0..rift_5 (the six rift frames, 40x96, vertical plane models), blissgems:rift_light (ground light spill) and HUD glyph U+E043 (blissgems:icons/relay_rift.png, 33x20). Time Dilate clock lines are 1.5x thicker and recoloured to glowing brown #B0703A / #8C5530 / #F0C48C; the brown Glowing outline is set by the plugin.

The Revenant: adds blissgems:revenant_mace (item definition, handheld_mace model, the supplied 16x16 texture) and HUD glyphs U+E046 Plunge, U+E047 Rising, U+E048 Undertow (blissgems:icons/revenant_*.png, 33x20).

Auratus rebuild: no new assets. The gem uses the main pack's chain and Aegis HUD glyphs (U+22B5, U+22B4) and echo shard models 12348, 12349, 12345 and 12346.

Finale: adds item models blissgems:finale_pedestal_auratus, blissgems:finale_pedestal_heretic (vanilla blackstone with gold or red trim) and blissgems:finale_seal (textures/item/finale_seal.png, a clock face laid on the ground under the merge).

Finale overlay as camera overlays: the plugin now shows the haze frames (textures/overlay/gold_0..5, red_0..5) as a camera overlay, the way a carved pumpkin's blur is drawn, through a fake helmet only that player sees. Titles were drawn at the GUI scale, so the frames ended up larger than the screen and invisible. Camera overlays are stretched to the screen at any GUI scale, in first person only. Fades step through gold_fade_1..4 and red_fade_1..4 (20-80% of frame 0's opacity, made by tools/pack/overlay_fades.py); with an older pack that lacks them, set finale.overlay.fade-steps to 0. The E100-E115 glyphs are no longer used by the plugin; E120 (the brown flash) still is.

New brown haze: gold_0..4 are the five new frames (played in order: frames 0 and 2 are the same image), set by finale.overlay.frame-count.gold = 5. gold_5 is a copy of gold_0, kept only so the old E105 font glyph still has its texture. gold_fade_1..4 are made from the new gold_0. The red frames are unchanged.

Auratus hook (re-added): models/custom/chain_end.json and textures/item/chain.png carry the wider arrowhead hook. Texture faces as built (up/down 180, east/west 270); needs the plugin build with the hook 180° turn fix. Pack format range 75-88 (1.21.11 to 26.2).

Glowing gems: blissgems:item/<gem>gemtier1 and <gem>gemtier2 for all eight gems are animated (12 frames, interpolated) with glowing facet lines like Auratus. The pristine 2-4 stage textures are not replaced.

Astra dagger: models/custom/astra_dagger.json and textures/item/astra_dagger.png are included here too, so the daggers render even if the main pack under this one is an older copy.

26.x fix: Minecraft 26.x refuses to load an item's models if any of them points at a missing texture ("Multiple atlases used in model"), which broke every custom nautilus shell model (the Astra daggers showed pink and black). This pack adds the 48 missing pristine 2-4 gem textures (glowing, same as the base gems) and the two allforone_gem textures (gold gem art as a placeholder).

Gold Gem sockets: 256 looks for the Gold Gem, one per combination of socketed gems, plus the awakened look.
- Set the item_model component to blissgems:gold/gold_gem_<bits>, where <bits> is 8 characters of 0/1 in this order: astra, fire, flux, life, puff, speed, strength, wealth (1 = socketed). Example: core Life plus Fire = blissgems:gold/gold_gem_01010000.
- Awakened (all 8 + the ritual): blissgems:gold/gold_gem_awakened, an animated version where the gold body pulses bright.


Special items: adds blissgems:upgrader, blissgems:trader and blissgems:energy_bottle (item definitions, plus the main pack's upgrader, trader and energy_bottle models and textures copied in, so they show even over an older main pack). The plugin sets these as the item_model of the Gem Upgrader, Gem Trader and Bottle of Energy.

Gold Gem repurpose overlay: textures/overlay/repurpose_<gem>_0..11.png (a seamless 12-frame loop), repurpose_<gem>_fade_1..4.png (1 the faintest) and repurpose_<gem>.png (frame 0) for astra, fire, flux, life, puff, speed, strength and wealth. The plugin fades the victim's screen in through the fade steps, then loops the frames (gold.repurpose.overlay).

The Lost Halo: items/halo/fragment_1..5 and items/halo/reliquary (models/item/halo, textures/item/halo; the fragments are animated, 2 ticks a frame). The plugin sets blissgems:halo/fragment_<n> as the item_model of Halo Fragment n and shows blissgems:halo/reliquary as the quartz-and-gold shrine under a fragment set with /halo reliquary (vanilla block textures).
